//
//  MasonryViewController.swift
//  SnapKitAndMasonry
//
//  Created by 黄嘉群 on 2020/12/7.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import UIKit

class MasonryViewController: UIViewController {
    var recommendADView:HomeHeaderRecommendADView!
    var headerIconADView:HomeHeaderIconADView!
    var headerPicADView:HomeHeaderPicADView!
    var headerActivityView:HomeHeaderActivityView!
    var headerTwoPicADView:HomeHeaderTwoPicADView!
    var headerHotIPView:HomeHeaderHotIPView!
    
    lazy var headerView: UIView = {
        let head = UIView()
        head.frame=CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 300)
        head.backgroundColor = UIColor.gray
        return head
    }()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor=UIColor.white
        recommendADView = HomeHeaderRecommendADView.init()
        headerIconADView = HomeHeaderIconADView.init()
        headerPicADView = HomeHeaderPicADView.init()
        headerActivityView = HomeHeaderActivityView.init()
        headerTwoPicADView = HomeHeaderTwoPicADView.init()
        headerHotIPView = HomeHeaderHotIPView.init()
        
        headerView.addSubview(recommendADView)
        headerView.addSubview(headerIconADView)
        headerView.addSubview(headerPicADView)
        headerView.addSubview(headerActivityView)
        headerView.addSubview(headerTwoPicADView)
        
        headerTwoPicADView.addSubview(headerHotIPView)
        
        
        self.view.addSubview(headerView)
        //gray
        recommendADView.mas_makeConstraints { (make) in
            make?.top.equalTo()(10)
            make?.left.equalTo()(0)
            make?.right.equalTo()(0)
            make?.height.equalTo()(30)
        }
        //red
        headerIconADView.mas_makeConstraints { (make) in
            make?.left.equalTo()(10)
            make?.right.equalTo()(-10)
            make?.top.equalTo()(recommendADView.mas_bottom)
            make?.height.equalTo()(30)
        }
        
        headerPicADView.mas_makeConstraints { (make) in
            make?.top.equalTo()(headerIconADView.mas_bottom)
            make?.left.equalTo()(20)
            make?.right.equalTo()(-20)
            make?.height.equalTo()(30)
        }
        //purple
        headerActivityView.mas_makeConstraints { (make) in
            make?.top.equalTo()(headerPicADView.mas_bottom)
            make?.left.equalTo()(30)
            make?.right.equalTo()(-30)
            make?.height.equalTo()(40)
        }
        //yellow
        headerTwoPicADView.mas_makeConstraints { (make) in
            make?.top.equalTo()(headerActivityView.mas_bottom)
            make?.left.equalTo()(10)
            make?.right.equalTo()(-10)
            make?.height.equalTo()(60)
        }
        
        
        headerHotIPView.mas_makeConstraints { (make) in
           // make?.top.equalTo()(5)
            //make?.left.right()?.equalTo()(10)
            make?.center.equalTo()(headerTwoPicADView.center)
            make?.height.width()?.equalTo()(20)
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIColor {
    
    convenience init(r:UInt64 ,g:UInt64 , b:UInt64 , a:CGFloat = 1.0) {
        self.init(red: CGFloat(r) / 255.0,
                  green: CGFloat(g) / 255.0,
                  blue: CGFloat(b) / 255.0,
                  alpha: a)
    }
    
    class func hex(hexString: String,alpha:CGFloat) -> UIColor {
        var cString: String = hexString.trimmingCharacters(in: .whitespacesAndNewlines)
        if cString.count < 6 { return UIColor.clear }
        
        let index = cString.index(cString.endIndex, offsetBy: -6)
        let subString = cString[index...]
        if cString.hasPrefix("0X") { cString = String(subString) }
        if cString.hasPrefix("#") { cString = String(subString) }
        
        if cString.count != 6 { return UIColor.black }
        
        var range: NSRange = NSMakeRange(0, 2)
        let rString = (cString as NSString).substring(with: range)
        range.location = 2
        let gString = (cString as NSString).substring(with: range)
        range.location = 4
        let bString = (cString as NSString).substring(with: range)
        
        var r: UInt64 = 0x0
        var g: UInt64 = 0x0
        var b: UInt64 = 0x0
        
        Scanner(string: rString).scanHexInt64(&r)
        Scanner(string: gString).scanHexInt64(&g)
        Scanner(string: bString).scanHexInt64(&b)
        
        return UIColor(r: r, g: g, b: b,a: alpha)
    }
}
