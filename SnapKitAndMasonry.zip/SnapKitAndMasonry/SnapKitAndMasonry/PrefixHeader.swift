//
//  PrefixHeader.swift
//  SnapKitAndMasonry
//
//  Created by 黄嘉群 on 2020/12/7.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import Foundation


import Masonry
//MARK: - 屏幕相关

let SCREEN_WIDTH: CGFloat       = UIScreen.main.bounds.size.width
let SCREEN_HEIGHT: CGFloat      = UIScreen.main.bounds.size.height

let IPHONE6_PLUS_HEIGHT: CGFloat      =       736.0
let IPHONE6_PLUS_WIDTH: CGFloat       =       414.0
let IPHONE6_WIDTH: CGFloat            =       375.0
let IPHONE6_HEIGHT: CGFloat           =       667.0
let IPHONE5_WIDTH: CGFloat            =       320.0
let IPHONE5_HEIGHT: CGFloat           =       568.0
let IPHONEX_HEIGHT: CGFloat           =       812.0
let IPHONE_XS_MAX_HEIGHT: CGFloat     =       896.0

let IS_IPHONE4 :Bool                  =       (SCREEN_HEIGHT<IPHONE5_HEIGHT)
let IS_IPHONE5 :Bool                  =       (SCREEN_HEIGHT==IPHONE5_HEIGHT)
let IS_IPHONE6 :Bool                  =       (SCREEN_HEIGHT==IPHONE6_HEIGHT)
let IS_IPHONE6_P:Bool                 =       (SCREEN_HEIGHT==IPHONE6_PLUS_HEIGHT)//414 736   1242  2208
//iphone4  320*480
//iphone5  320*568    0.56338
//iphone6  375*667    0.56222
//iphone6p 414*736    0.5625
//iphone11,iphone11 pro max,iphoneXR,iPhoneXs Max 414*896   0.46205
//iphone11 pro,iphoneX,iPhoneXs 375*812   0.46812

//iphone12 pro max 428*926
//iphone12,iphone12 pro 390*844
//iphone12 min 360*780

let IS_PAD :Bool                        = UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad

//------------iphonex、iphone11系列系列
//375*812
let IS_IPHONE_X :Bool                   = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1125, height: 2436), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//414*896
let IS_IPHONE_XR :Bool                  = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 828, height: 1792), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//375*812
let IS_IPHONE_XR2 :Bool                 = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 750, height: 1624), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//375*812 判断iPhoneXs
let IS_IPHONE_XS :Bool                  = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1125, height: 2436), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//414*896判断iPhoneXs Max
let IS_IPHONE_XS_MAX :Bool              = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1242, height: 2688), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//------------iphone12系列
let IS_IPHONE_12_MIN :Bool              = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1080, height: 2340), UIScreen.main.currentMode!.size) && !IS_PAD : false)

//IS_IPHONE_12、IS_IPHONE_12_PRO
let IS_IPHONE_12 :Bool                  = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1170, height: 2530), UIScreen.main.currentMode!.size) && !IS_PAD : false)

let IS_IPHONE_12_PRO_MAX :Bool          = (UIScreen.instancesRespond(to: #selector(getter: UIScreen.currentMode)) ? __CGSizeEqualToSize(CGSize(width: 1284, height: 2778), UIScreen.main.currentMode!.size) && !IS_PAD : false)


let IS_IPHONE_12_SERIES:Bool            = IS_IPHONE_12_MIN || IS_IPHONE_12 || IS_IPHONE_12_PRO_MAX

let IS_IPHONE_X_SERIES :Bool            = (IS_IPHONE_X || IS_IPHONE_XR || IS_IPHONE_XR2 || IS_IPHONE_XS || IS_IPHONE_XS_MAX)

//是否是刘海屏
let IS_IPHONE_FRINGE :Bool              = IS_IPHONE_X_SERIES || IS_IPHONE_12_SERIES

let STATUSBAR_HEIGHT: CGFloat           = UIApplication.shared.statusBarFrame.size.height

let NAV_HEIGHT: CGFloat                 = 44//导航栏高度

let IPHONE_X_TOP: CGFloat               = (STATUSBAR_HEIGHT+NAV_HEIGHT)

let TABBAR_HEIGHT: CGFloat              = 49//底部tabbar高度

let SAFE_AREA_BOTTOM_HEIGHT: CGFloat    = (IS_IPHONE_FRINGE ? (IS_IPHONE_XR2 ? 31 : 34) :0)


let DEVICE_WIDTH_SCALE: CGFloat         = (SCREEN_WIDTH / IPHONE6_WIDTH)
let DEVICE_HEIGHT_SCALE: CGFloat        = (SCREEN_HEIGHT / IPHONE6_HEIGHT)

let DEVICE_WIDTH_SCALE_MAX: CGFloat     = (SCREEN_WIDTH / IPHONE6_PLUS_WIDTH)
let DEVICE_HEIGHT_SCALE_MAX: CGFloat    = (SCREEN_HEIGHT / IPHONE_XS_MAX_HEIGHT)
