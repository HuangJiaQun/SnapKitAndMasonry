//
//  ViewController.swift
//  SnapKitAndMasonry
//
//  Created by 黄嘉群 on 2020/12/7.
//  Copyright © 2020 黄嘉群. All rights reserved.
//

import UIKit
import SnapKit
class ViewController: UIViewController {
    
    var recommendADView:HomeHeaderRecommendADView!
    var headerIconADView:HomeHeaderIconADView!
    var headerPicADView:HomeHeaderPicADView!
    var headerActivityView:HomeHeaderActivityView!
    var headerTwoPicADView:HomeHeaderTwoPicADView!
    var headerHotIPView:HomeHeaderHotIPView!
    
    lazy var headerView: UIView = {
        let head = UIView()
        head.frame=CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 300)
        head.backgroundColor = UIColor.gray
        return head
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
//        通过 snp.makeConstraints 方法给view添加约束，约束有几种，分别是边距，宽，高，左上右下距离，基准线。
//        同时，添加过约束后可以有修正，修正有位移修正（inset、offset）和倍率修正（multipliedBy）
//
//        语法一般是： make.equalTo 或 make.greaterThanOrEqualTo 或 make.lessThanOrEqualTo + 倍数和位移修正。
//
//            .equalTo：等于
//            .lessThanOrEqualTo：小于等于
//            .greaterThanOrEqualTo：大于等于
//
//        注意： 使用 snp.makeConstraints 方法的元素必须事先添加到父元素的中，例如：self.view.addSubview(view)
        // Do any additional setup after loading the view.
        
//        视图属性（ViewAttribute）    布局属性（NSLayoutAttribute）
//        view.snp.left    NSLayoutAttribute.Left
//        view.snp.right    NSLayoutAttribute.Right
//        view.snp.top    NSLayoutAttribute.Top
//        view.snp.bottom    NSLayoutAttribute.Bottom
//        view.snp.leading    NSLayoutAttribute.Leading
//        view.snp.trailing    NSLayoutAttribute.Trailing
//        view.snp.width    NSLayoutAttribute.Width
//        view.snp.height    NSLayoutAttribute.Height
//        view.snp.centerX    NSLayoutAttribute.CenterX
//        view.snp.centerY    NSLayoutAttribute.CenterY
//        view.snp.baseline    NSLayoutAttribute.Baseline
        
        self.view.backgroundColor=UIColor.white
        recommendADView = HomeHeaderRecommendADView.init()
        headerIconADView = HomeHeaderIconADView.init()
        headerPicADView = HomeHeaderPicADView.init()
        headerActivityView = HomeHeaderActivityView.init()
        headerTwoPicADView = HomeHeaderTwoPicADView.init()
        headerHotIPView = HomeHeaderHotIPView.init()
        
        headerView.addSubview(recommendADView)
        headerView.addSubview(headerIconADView)
        headerView.addSubview(headerPicADView)
        headerView.addSubview(headerActivityView)
        headerView.addSubview(headerTwoPicADView)
        
        headerTwoPicADView.addSubview(headerHotIPView)
        
        
        self.view.addSubview(headerView)
        
        
        //gray
        recommendADView.snp.makeConstraints({ (make) in
            make.top.equalTo(10)
            make.left.equalTo(10)
            make.right.equalTo(0)
            make.height.equalTo(30)
        })
        //red
        headerIconADView.snp.makeConstraints({ (make) in
            make.left.equalTo(10)
            make.right.equalTo(-10)
            make.top.equalTo(recommendADView.snp.bottom).offset(20)
            make.height.equalTo(30)
        })
        
        headerPicADView.snp.makeConstraints({ (make) in
            make.top.equalTo(headerIconADView?.snp.bottom ?? 0)
            make.left.equalTo(20)
            make.right.equalTo(-20)
            make.height.equalTo(30)
        })
        //purple
        headerActivityView.snp.makeConstraints({ (make) in
            make.top.equalTo(headerPicADView!.snp.bottom)
            make.left.equalTo(30)
            make.right.equalTo(-30)
            make.height.equalTo(40)
        })
        //yellow
        headerTwoPicADView.snp.makeConstraints({ (make) in
            make.top.equalTo(headerActivityView!.snp.bottom)
            make.left.equalTo(10)
            make.right.equalTo(-10)
            make.height.equalTo(60)
        })
        
        
        headerHotIPView.snp.makeConstraints({ (make) in
            // make?.top.equalTo()(5)
            //make?.left.right()?.equalTo()(10)
            make.center.equalTo(headerTwoPicADView)
            make.height.width.equalTo(20)
            
        })
    }


}

